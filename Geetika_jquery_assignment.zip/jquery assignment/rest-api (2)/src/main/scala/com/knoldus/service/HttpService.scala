package com.knoldus.service

import java.sql.{DriverManager, Connection}

import akka.actor.ActorSystem
import akka.http.scaladsl.Http

import akka.stream.ActorMaterializer
import com.knoldus.repo.repo.{StudentRepository, Student}

import scala.collection.mutable.ListBuffer

//import scala.concurrent.ExecutionContext.Implicits.global


object HttpService extends App with Routes with FakeRepo {

  implicit val system = ActorSystem()
  implicit val materializer = ActorMaterializer()

  Http().bindAndHandle(route, "localhost", 9000)



}

trait FakeRepo extends StudentRepository {

  def create(student:Student):Student= {
  val con=getConnection()
      val statement = con.createStatement()
      val res = statement.executeUpdate("Insert into student values(" +student.id+ ",'" + student.name + "','" + student.email + "');")

      Student(student.id, student.name, student.email)

  }

  def getById(id:Int):Student = {

    val con = getConnection()

    val statement = con.createStatement()
    val res = statement.executeQuery("Select * from student where id=" + id + ";")
    if (res.next()) {
      val id = res.getInt(1)
      val name = res.getString(2)
      val email = res.getString(3)
      Student(id, name, email)

    }
    else
      Student(0, "", "")
  }

  def getAll():List[Student]={

    val con = getConnection()
  val l:ListBuffer[Student]=ListBuffer()
    val statement = con.createStatement()
    val res = statement.executeQuery("Select * from student ;")
    while(res.next()) {
      val id = res.getInt(1)
      val name = res.getString(2)
      val email = res.getString(3)
      l+=Student(id, name, email)
    }

    l.toList
     }

  def getConnection(): Connection = {

    val url = "jdbc:mysql://localhost/student"
    val username = "root"
    val password = "root"
    Class.forName("com.mysql.jdbc.Driver")
    val connection = DriverManager.getConnection(url, username, password)
    connection

  }
}